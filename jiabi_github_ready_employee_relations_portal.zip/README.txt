JIABI Employee Relations Portal - GitHub Pages Upload

Upload BOTH items to your GitHub repository root:
1. index.html
2. assets/jiabi_logo_clean.png

Important:
- The main HTML file must be named exactly: index.html
- The logo must stay inside: assets/jiabi_logo_clean.png
- Do not upload only the HTML without the assets folder.
- After upload, go to Settings > Pages > Deploy from branch > main > root > Save.
- Admin demo password: admin123
